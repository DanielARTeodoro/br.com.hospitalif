/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.hospitalif.app;

import java.io.IOException;

import br.com.hospitalif.util.Rotas;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Daniel
 * 
 */

public class Inicio extends Application {

	static Stage stageAtual;
	static FXMLLoader loader;

	@Override
	public void start(Stage stage) {

		stageAtual = stage;
		loader = new FXMLLoader(getClass().getResource(Rotas.LOGIN));

		Parent root;

		try {

			root = loader.load();
			Scene scene = new Scene(root, 600, 400);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();

		}

	}

	public void openLogin(String rota) {
		loader = new FXMLLoader(getClass().getResource(rota));

		Scene scene = null;
		try {
			scene = new Scene(loader.load());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stageAtual.setScene(scene);
		stageAtual.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Carregando... ");

		/// launch(args);

	}

}
