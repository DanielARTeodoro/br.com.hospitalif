/**
 * 
 */
package br.com.hospitalif.controller;

/**
 * @author Daniel
 *
 */
public class FuncionarioPessoaController {

}
