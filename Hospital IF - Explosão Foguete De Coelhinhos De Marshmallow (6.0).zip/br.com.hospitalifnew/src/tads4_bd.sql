-- tads4_bd -> utf8_general_ci = Banco de Dados >>> No PhpMyAdmim ou no Workbench CE.

create table tb_enfermidade(
   idEnfermidade integer not null auto_increment,
   descricao varchar (255),
   nome varchar (255),
   tipo varchar (255),
   constraint PK_Enfermidade primary key (idEnfermidade)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_pessoa(
   idPessoa integer not null auto_increment,
   cpf varchar (255),
   idade integer,
   nome varchar (255),
   sexo varchar (1),
   statusDePessoa varchar (255),
   tipoSanguineo varchar (255),
   constraint PK_Pessoa primary key (idPessoa)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_funcionariopessoa(
   idFuncionario integer not null auto_increment,
   cargo varchar (255),
   especialidade varchar (255),
   login varchar (255),
   numeroDeRegistroEnfermeiro integer,
   numeroDeRegistroMedico integer,
   senha varchar (255),
   statusDeUsuario varchar (255),
   fk_idPessoa integer,
   constraint PK_Funcionario primary key (idFuncionario),
   constraint FK_Pessoa_FuncionarioPessoa foreign key (fk_idPessoa) references tb_pessoa (idPessoa)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_paciente(
   idPaciente integer not null auto_increment,
   fk_idPessoa integer,
   constraint PK_Paciente primary key (idPaciente),
   constraint FK_Pessoa_paciente foreign key (fk_idPessoa) references tb_pessoa (idPessoa)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_entrada(
   idEntrada integer not null auto_increment,
   dataEntrada date,
   dataSaida date,
   statusEntrada varchar (255),
   fk_idPaciente integer,
   fk_idEntrada integer,
   constraint PK_Entrada primary key (idEntrada),
   constraint FK_Paciente_entrada foreign key (fk_idPaciente) references tb_paciente (idPaciente),
   constraint FK_Entrada_entrada foreign key (fk_idEntrada) references tb_entrada (idEntrada)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_atendimento(
   idAtendimento integer not null auto_increment,
   altura float,
   comentarioEnfermeiro varchar (255),
   comentarioMedico varchar (255),
   data date,
   peso float,
   fk_idFuncionarioPessoa integer,
   fk_idEntrada integer,
   constraint PK_Atendimento primary key (idAtendimento),
   constraint FK_FuncionarioPessoa_atendimento foreign key (fk_idFuncionarioPessoa) references tb_funcionariopessoa (idFuncionario),
   constraint FK_Entrada_atendimento foreign key (fk_idEntrada) references tb_entrada (idEntrada)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;

create table tb_enfermidadepessoal(
   idEnfermidadePessoal integer not null auto_increment,
   comentario varchar (255),
   statusDeEnfermidade varchar (255),
   fk_idAtendimento integer,
   fk_idEnfermidade integer,
   fk_idPaciente integer,
   constraint PK_EnfermidadePessoal primary key (idEnfermidadePessoal),
   constraint FK_Atendimento_enfermidadePessoal foreign key (fk_idAtendimento) references tb_atendimento (idAtendimento),
   constraint FK_Enfermidade_enfermidadePessoal foreign key (fk_idEnfermidade) references tb_enfermidade (idEnfermidade),
   constraint FK_Paciente_enfermidadePessoal foreign key (fk_idPaciente) references tb_Paciente (idPaciente)
)ENGINE= InnoDB DEFAULT CHARSET= utf8;

SET FOREIGN_KEY_CHECKS= 0;


-- ------------------------------

-- Pessoa

SELECT `tb_pessoa`.`idPessoa`,
    `tb_pessoa`.`cpf`,
    `tb_pessoa`.`idade`,
    `tb_pessoa`.`nome`,
    `tb_pessoa`.`sexo`,
    `tb_pessoa`.`statusDePessoa`,
    `tb_pessoa`.`tipoSanguineo`
FROM `bd`.`tb_pessoa`;

-- Enfermidade Pessoal

SELECT `tb_enfermidadepessoal`.`idEnfermidadePessoal`,
    `tb_enfermidadepessoal`.`comentario`,
    `tb_enfermidadepessoal`.`statusDeEnfermidade`,
    `tb_enfermidadepessoal`.`fk_idAtendimento`,
    `tb_enfermidadepessoal`.`fk_idEnfermidade`,
    `tb_enfermidadepessoal`.`fk_idPaciente`
FROM `bd`.`tb_enfermidadepessoal`;

-- ---------------------------------

-- Atendimento

SELECT `tb_atendimento`.`idAtendimento`,
    `tb_atendimento`.`altura`,
    `tb_atendimento`.`comentarioEnfermeiro`,
    `tb_atendimento`.`comentarioMedico`,
    `tb_atendimento`.`data`,
    `tb_atendimento`.`peso`,
    `tb_atendimento`.`fk_idFuncionarioPessoa`,
    `tb_atendimento`.`fk_idEntrada`
FROM `bd`.`tb_atendimento`;

select p.nome, enfp.comentario, enfp.statusDeEnfermidade 
from tb_atendimento a, tb_enfermidadepessoal enfp, tb_pessoa p 
group by p.nome ASC;

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `view_atendimento` AS(
    SELECT 
        `p`.`nome` AS `Nome`,
        `enfp`.`comentario` AS `Comentario`,
        `enfp`.`statusDeEnfermidade` AS `Status De Enfermidade`
    FROM
        ((`tb_atendimento` `a`
        JOIN `tb_enfermidadepessoal` `enfp`)
        JOIN `tb_pessoa` `p`)
    GROUP BY `p`.`nome`);
    
    SELECT `view_atendimento`.`Nome`,
    `view_atendimento`.`Comentario`,
    `view_atendimento`.`Status De Enfermidade`
FROM `bd`.`view_atendimento`;



-- -------------------------

-- Entrada

SELECT `tb_entrada`.`idEntrada`,
    `tb_entrada`.`dataEntrada`,
    `tb_entrada`.`dataSaida`,
    `tb_entrada`.`statusEntrada`,
    `tb_entrada`.`fk_idPaciente`,
    `tb_entrada`.`fk_idEntrada`
FROM `bd`.`tb_entrada`;

select p.nome, ate.comentarioEnfermeiro, ate.comentarioMedico, ate.peso, ate.altura, ate.data 
from tb_entrada ent, tb_atendimento ate, tb_pessoa p
group by p.nome ASC;

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `view_entrada` AS
    SELECT 
        `p`.`nome` AS `nome`,
        `ate`.`comentarioEnfermeiro` AS `comentarioEnfermeiro`,
        `ate`.`comentarioMedico` AS `comentarioMedico`,
        `ate`.`peso` AS `peso`,
        `ate`.`altura` AS `altura`,
        `ate`.`data` AS `data`
    FROM
        ((`tb_entrada` `ent`
        JOIN `tb_atendimento` `ate`)
        JOIN `tb_pessoa` `p`)
    GROUP BY `p`.`nome`;
    
    SELECT `view_entrada`.`nome`,
    `view_entrada`.`comentarioEnfermeiro`,
    `view_entrada`.`comentarioMedico`,
    `view_entrada`.`peso`,
    `view_entrada`.`altura`,
    `view_entrada`.`data`
FROM `bd`.`view_entrada`;


-- ----------------------------------

-- Paciente

SELECT `tb_paciente`.`idPaciente`,
    `tb_paciente`.`fk_idPessoa`
FROM `bd`.`tb_paciente`;

-- view_paciente0

select p.nome, enfp.comentario, enfp.statusDeEnfermidade 
from tb_paciente, tb_enfermidadepessoal enfp, tb_pessoa p 
group by p.nome ASC;


CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `view_paciente0` AS
    SELECT 
        `p`.`nome` AS `nome`,
        `enfp`.`comentario` AS `comentario`,
        `enfp`.`statusDeEnfermidade` AS `statusDeEnfermidade`
    FROM
        ((`tb_paciente`
        JOIN `tb_enfermidadepessoal` `enfp`)
        JOIN `tb_pessoa` `p`)
    GROUP BY `p`.`nome`;


   SELECT `view_paciente0`.`nome`,
    `view_paciente0`.`comentario`,
    `view_paciente0`.`statusDeEnfermidade`
FROM `bd`.`view_paciente0`;

-- view_paciente1

select p.nome, ent.dataEntrada, ent.dataSaida, ent.statusEntrada
from tb_paciente, tb_entrada ent, tb_pessoa p
group by p.nome ASC;

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `view_paciente1` AS
    SELECT 
        `p`.`nome` AS `nome`,
        `ent`.`dataEntrada` AS `dataEntrada`,
        `ent`.`dataSaida` AS `dataSaida`,
        `ent`.`statusEntrada` AS `statusEntrada`
    FROM
        ((`tb_paciente`
        JOIN `tb_entrada` `ent`)
        JOIN `tb_pessoa` `p`)
    GROUP BY `p`.`nome`;
    
    SELECT `view_paciente1`.`nome`,
    `view_paciente1`.`dataEntrada`,
    `view_paciente1`.`dataSaida`,
    `view_paciente1`.`statusEntrada`
FROM `bd`.`view_paciente1`;


-- view_paciente

select p.nome, enfp.comentario, enfp.statusDeEnfermidade, ent.dataEntrada, ent.dataSaida, ent.statusEntrada 
from tb_paciente, tb_enfermidadepessoal enfp, tb_entrada ent, tb_pessoa p 
group by p.nome ASC;
    
    CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `view_paciente` AS
    SELECT 
        `p`.`nome` AS `nome`,
        `enfp`.`comentario` AS `comentario`,
        `enfp`.`statusDeEnfermidade` AS `statusDeEnfermidade`,
        `ent`.`dataEntrada` AS `dataEntrada`,
        `ent`.`dataSaida` AS `dataSaida`,
        `ent`.`statusEntrada` AS `statusEntrada`
    FROM
        (((`tb_paciente`
        JOIN `tb_enfermidadepessoal` `enfp`)
        JOIN `tb_entrada` `ent`)
        JOIN `tb_pessoa` `p`)
    GROUP BY `p`.`nome`;
    
    SELECT `view_paciente`.`nome`,
    `view_paciente`.`comentario`,
    `view_paciente`.`statusDeEnfermidade`,
    `view_paciente`.`dataEntrada`,
    `view_paciente`.`dataSaida`,
    `view_paciente`.`statusEntrada`
FROM `bd`.`view_paciente`;

-- -------------

-- view_paciente 0 e 1 Duas Chamadas -> Paciente

select * from view_paciente0, view_paciente1;

-- view_paciente Uma Chamada -> Paciente

select * from view_paciente;

-- view_entrada Uma Chamada -> Entrada

select * from view_entrada;

-- view_atendimento Uma Chamada -> Atendimento

select * from view_atendimento;

