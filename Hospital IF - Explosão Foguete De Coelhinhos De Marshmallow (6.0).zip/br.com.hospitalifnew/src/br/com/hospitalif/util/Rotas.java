/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package br.com.hospitalif.util;

/**
*
* @author Daniel
*/

public class Rotas {
	
	
	public static String ADMINISTRADOR = "/view/Administrador.fxml";
	public static String ATENDENTE = "/view/Atendente.fxml";
	public static String ATENDIMENTO = "/view/Atendimento.fxml";
	public static String HOME = "/view/Home.fxml";
	public static String ENFERMEIRO = "/view/Enfermeiro.fxml";
	public static String ENFERMIDADE = "/view/Enfermidade.fxml";
	public static String ENFERMIDADEPESSOAL = "/view/EnfermidadePessoal.fxml";
	public static String ENTRADA = "/view/Entrada.fxml";
	public static String FUNCIONARIO = "/view/Funcionario.fxml";
	public static String GERENTE = "/view/Gerente.fxml";
	public static String LOGIN = "/view/Login.fxml";
	public static String MEDICO = "/view/Medico.fxml";
	public static String PACIENTE = "/view/Paciente.fxml";
	public static String PESSOAADM = "/view/PessoaAdm.fxml";
	public static String PESSOAATE = "/view/PessoaAte.fxml";
	public static String FUNCIONARIOPESSOA = "/view/FuncionarioPessoa.fxml";
	public static String PACIENTEPESSOA = "/view/PacientePessoa.fxml";
	public static String APP = "/css/app.css";
	public static String ADMINISTRADORCSS = "/css/Administrador.css";
	public static String ATENDENTECSS = "/css/Atendente.css";
	public static String ATENDIMENTOCSS = "/css/Atendimento.css";
	public static String ENFERMIDADECSS = "/css/Enfermidade.css";
	public static String PESSOASCSS = "/css/Pessoas.css";

}
