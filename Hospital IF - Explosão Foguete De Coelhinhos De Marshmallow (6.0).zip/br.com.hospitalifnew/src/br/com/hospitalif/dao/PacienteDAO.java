/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.EnfermidadePessoal;
import br.com.hospitalif.model.Paciente;

public class PacienteDAO {

	public void read(Paciente pa) {
		
		List<EnfermidadePessoal> doencas = new ArrayList<EnfermidadePessoal>();
		try {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlLer = "select * from view_paciente0, view_paciente1"; 
		/// Ou select * from view_paciente; 
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlLer);
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			while (rs.next()) {
				//Paciente pa = new Paciente();
				//pa.setDoenca(doenca);
				//pa.setHistorico(historico);
				doencas.addAll(doencas);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//return doencas;
	}
 

}
