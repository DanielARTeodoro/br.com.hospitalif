/**
 * Sample Skeleton for 'Atendimento.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.AtendimentoDAO;
import br.com.hospitalif.model.Atendimento;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AtendimentoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnAtendimento"
	private Button btnAtendimento; // Value injected by FXMLLoader
	
	@FXML // fx:id="txtAtendimento10"
    private TableView<?> txtAtendimento10; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento4"
	private TableColumn<?, ?> txtAtendimento4; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento5"
	private TableColumn<?, ?> txtAtendimento5; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento6"
	private TableColumn<?, ?> txtAtendimento6; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento"
	private TextField txtAtendimento; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento0"
	private TextField txtAtendimento0; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento2"
	private TextArea txtAtendimento2; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento3"
	private TextArea txtAtendimento3; // Value injected by FXMLLoader

	@FXML // fx:id="txtAtendimento1"
	private DatePicker txtAtendimento1; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws SQLException {

		if (txtAtendimento.getText().equals("")) {
			Stage stage = (Stage) btnAtendimento.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.ATENDIMENTO));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene Scene = new Scene(root);
			Scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(Scene);
			stage.show();
		} else {
			Atendimento a = new Atendimento();
			AtendimentoDAO aD = new AtendimentoDAO();

			String comentarioEnfermeiro = (txtAtendimento2.getText());
			String comentarioMedico = (txtAtendimento3.getText());
			Float peso = Float.parseFloat((String) (txtAtendimento.getText()));
			Float altura = Float.parseFloat((String) (txtAtendimento0.getText()));
			LocalDate data = txtAtendimento1.getValue();

			a.setAltura(altura);
			a.setPeso(peso);
			a.setComentarioEnfermeiro(comentarioEnfermeiro);
			a.setComentarioMedico(comentarioMedico);
			a.setData(data);
			aD.create(a);

			Stage stage = (Stage) btnAtendimento.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.ATENDIMENTO));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene Scene = new Scene(root);
			Scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(Scene);
			stage.show();

		}

	}
	
	public void lista(URL arg0, ResourceBundle arg1) {
		txtAtendimento4.setCellValueFactory(new PropertyValueFactory<>("nome"));
		txtAtendimento5.setCellValueFactory(new PropertyValueFactory<>("comentario"));
		txtAtendimento6.setCellValueFactory(new PropertyValueFactory<>("statusDeEnfermidade"));
		
		

		//AtendimentoDAO enfpDAO = new AtendimentoDAO();
		//List<EnfermidadePessoal> doencas = enfpDAO.read(enfpDAO);

		//ObservableList<?> obsA = FXCollections.observableArrayList(doencas);

		//txtAtendimento10.setItems((ObservableList<?>) obsA);
		

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnAtendimento != null : "fx:id=\"btnAtendimento\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento4 != null : "fx:id=\"txtAtendimento4\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento5 != null : "fx:id=\"txtAtendimento5\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento6 != null : "fx:id=\"txtAtendimento6\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento != null : "fx:id=\"txtAtendimento\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento0 != null : "fx:id=\"txtAtendimento0\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento2 != null : "fx:id=\"txtAtendimento2\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento3 != null : "fx:id=\"txtAtendimento3\" was not injected: check your FXML file 'Atendimento.fxml'.";
		assert txtAtendimento1 != null : "fx:id=\"txtAtendimento1\" was not injected: check your FXML file 'Atendimento.fxml'.";

	}
}
