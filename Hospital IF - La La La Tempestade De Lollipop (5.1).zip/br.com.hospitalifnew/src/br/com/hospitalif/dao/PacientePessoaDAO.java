/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.PacientePessoa;

public class PacientePessoaDAO {
	
	  public void read(PacientePessoa ppa) { 
	  Conexao conn = new Conexao(); 
	  Connection conexao = conn.getConnection();
	  System.out.println(conn.getStatus());
	  String sqlLer =
	  "select tb_pessoa.nome, tb_funcionariopessoa.numeroDeRegistroEnfermeiro, tb_funcionariopessoa.numeroDeRegistroMedico, tb_funcionariopessoa.especialidade, tb_atendimento, tb_enfermidadepessoal.*, tb_enfermidade.*, tb_entrada.*, tb_paciente.* from tb_pessoa, tb_funcionariopessoa, tb_atendimento, tb_enfermidadepessoal, tb_enfermidade, tb_entrada, tb_paciente group by tb_pessoa.nome ASC"; 
	  PreparedStatement stmt = null;
	try {
		stmt = conexao.prepareStatement(sqlLer);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  ResultSet rs = null;
	try {
		rs = stmt.executeQuery();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  List<PacientePessoa> pacientePessoas = new ArrayList<PacientePessoa>(); 
	  try {
		while (rs.next()) { 
		  PacientePessoa ppa1 = new PacientePessoa(); 
		  ppa1.getComentarioEnfermeiro(); 
		  ppa1.getComentarioMedico();
		  pacientePessoas.add(ppa1); 
		  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  }

	  /*
		public void update(Atendimento a) throws SQLException {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlAtualizar = "UPDATE Atendimento a set(?,?,?,?,?) where id=(?) ";
			PreparedStatement stmt = conexao.prepareStatement(sqlAtualizar);

			stmt.setString(3, a.getComentarioEnfermeiro());
			stmt.setString(4, a.getComentarioMedico());
			stmt.setFloat(2, a.getPeso());
			stmt.setFloat(1, a.getAltura());
			stmt.setDate(5, (Date) a.getData());

			stmt.execute();

		}

		public void delete(int id) throws SQLException {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlApagar = "DELETE from Atendimento where id =(?)";
			PreparedStatement stmt = conexao.prepareStatement(sqlApagar);

			stmt.setInt(1, id);
			stmt.execute();

		}
	*/
	  
}
