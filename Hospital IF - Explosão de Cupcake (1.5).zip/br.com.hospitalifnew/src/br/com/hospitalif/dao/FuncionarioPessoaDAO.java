/**
 * 
 */
package br.com.hospitalif.dao;

/**
 * @author Daniel
 *
 */
public class FuncionarioPessoaDAO {

}
