/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Daniel
 *
 */
public class DAO {

	public String status = "N�o conectado!";

	Connection conn = null;
	private Statement stmt = null;
	private String user = "root";
	private String pwd = "";
	private String driverName = "com.mysql.jdbc.Driver";
	private String server = "localhost";
	private String bdName = "tads4_bd";
	private String url = "jdbc:mysql://" + server + ":3306/tads4_bd" + bdName;

	// M�todo para devolver a conexao
	public Connection getConnection() {
		try {
			Class.forName(this.driverName);
			this.conn = DriverManager.getConnection(url, user, pwd);
			this.stmt = this.conn.createStatement();

			if (conn != null) {
				this.status = "STATUS --> Conectado com sucesso";
			} else {
				this.status = "STATUS --> Ainda n�o conectado";
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return this.conn;

	}

	public String getStatus() {
		return this.status;
	}

	public boolean closeConnection() {

		return false;
	}

	public void resetConnection() throws SQLException {
		this.closeConnection();
		this.closeConnection();
		this.getConnection();
	}

}
