/**
 * 
 */
package br.com.hospitalif.dao;

/**
 * @author Frank
 *
 */
public class GerentdeDAO extends FuncionarioDAO {

}
