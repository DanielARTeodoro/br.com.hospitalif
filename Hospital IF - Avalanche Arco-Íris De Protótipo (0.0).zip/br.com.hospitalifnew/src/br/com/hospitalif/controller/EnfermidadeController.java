/**
 * Sample Skeleton for 'Enfermidade.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.AtendimentoDAO;
import br.com.hospitalif.model.Atendimento;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EnfermidadeController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="txtEnfermidade1"
    private TextField txtEnfermidade1; // Value injected by FXMLLoader

    @FXML // fx:id="txtEnfermidade2"
    private TextField txtEnfermidade2; // Value injected by FXMLLoader

    @FXML // fx:id="txtEnfermidade3"
    private TextField txtEnfermidade3; // Value injected by FXMLLoader

    @FXML // fx:id="btnEnfermidade"
    private Button btnEnfermidade; // Value injected by FXMLLoader

    @FXML
    void handleSubmitButtonAction(ActionEvent event) throws IOException {
    	if (btnEnfermidade.getText().equals("")) { Stage stage = (Stage)
    			btnEnfermidade.getScene().getWindow(); Parent root =
				  FXMLLoader.load(getClass().getResource("../view/Enfermidade.fxml")); Scene scene =
				  new Scene(root);
				  //scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
				  //toExternalForm()); stage.setTitle("Alerta: ERRO!"); stage.setScene(scene);
				  stage.show();
						  } else { Enfermidade en = new Enfermidade();
				 
				  en.setNome(txtEnfermidade1.getText());
				  en.setTipo(txtEnfermidade2.getText());
				  en.setDescri��o(txtEnfermidade3.getText());

				  
				  
				 
				  EnfermidadeDAO efdaoe = new EnfermidadeDAO(); 
				  efdaoe.inserir(en);
				  
				  Stage stage = (Stage) btnEnfermidade.getScene().getWindow(); Parent root =
				  FXMLLoader.load(getClass().getResource("../view/Enfermidade.fxml")); Scene scene =
				  new Scene(root);
				  //scene.getStylesheets().add(getClass().getResource("/css/estilo.css").
				  //toExternalForm()); stage.setTitle("Alerta: Sucesso!"); stage.setScene(scene);
				  stage.show(); }

	}

    }

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert txtEnfermidade1 != null : "fx:id=\"txtEnfermidade1\" was not injected: check your FXML file 'Enfermidade.fxml'.";
        assert txtEnfermidade2 != null : "fx:id=\"txtEnfermidade2\" was not injected: check your FXML file 'Enfermidade.fxml'.";
        assert txtEnfermidade3 != null : "fx:id=\"txtEnfermidade3\" was not injected: check your FXML file 'Enfermidade.fxml'.";
        assert btnEnfermidade != null : "fx:id=\"btnEnfermidade\" was not injected: check your FXML file 'Enfermidade.fxml'.";

    }
}
