/**
 * 
 */
package br.com.hospitalif.controller;

/**
 * @author Frank
 *
 */
public class FuncionarioPessoaController {

}
