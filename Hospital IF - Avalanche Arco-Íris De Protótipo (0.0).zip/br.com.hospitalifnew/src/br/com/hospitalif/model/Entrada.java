/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.model;

import java.util.Date;
import java.util.List;

/**
 * @author Frank
 *
 */
public class Entrada {

	private int idEntrada;
	private Date dataEntrada;
	private Date dataSaida;
	private String statusEntrada;
	private List<Atendimento> situacaoDePaciente;

	/**
	 * 
	 */
	public Entrada() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the idEntrada
	 */
	public int getIdEntrada() {
		return idEntrada;
	}

	/**
	 * @param idEntrada the idEntrada to set
	 */
	public void setIdEntrada(int idEntrada) {
		this.idEntrada = idEntrada;
	}

	/**
	 * @return the dataEntrada
	 */
	public Date getDataEntrada() {
		return dataEntrada;
	}

	/**
	 * @param dataEntrada the dataEntrada to set
	 */
	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	/**
	 * @return the dataSaida
	 */
	public Date getDataSaida() {
		return dataSaida;
	}

	/**
	 * @param dataSaida the dataSaida to set
	 */
	public void setDataSaida(Date dataSaida) {
		this.dataSaida = dataSaida;
	}

	/**
	 * @return the statusEntrada
	 */
	public String getStatusEntrada() {
		return statusEntrada;
	}

	/**
	 * @param statusEntrada the statusEntrada to set
	 */
	public void setStatusEntrada(String statusEntrada) {
		this.statusEntrada = statusEntrada;
	}

	/**
	 * @return the situacaoDePaciente
	 */
	public List<Atendimento> getSituacaoDePaciente() {
		return situacaoDePaciente;
	}

	/**
	 * @param situacaoDePaciente the situacaoDePaciente to set
	 */
	public void setSituacaoDePaciente(List<Atendimento> situacaoDePaciente) {
		this.situacaoDePaciente = situacaoDePaciente;
	}

}
