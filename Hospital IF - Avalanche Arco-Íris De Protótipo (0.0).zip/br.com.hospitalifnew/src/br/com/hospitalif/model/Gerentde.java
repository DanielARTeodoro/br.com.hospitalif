/**
 * 
 */
package br.com.hospitalif.model;

/**
 * @author Frank
 *
 */
public class Gerentde extends Funcionario {

	private String cargo;

	/**
	 * 
	 */
	public Gerentde() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * @param cargo the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

}
