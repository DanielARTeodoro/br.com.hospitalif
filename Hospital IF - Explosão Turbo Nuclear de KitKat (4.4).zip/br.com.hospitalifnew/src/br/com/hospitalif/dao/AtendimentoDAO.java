/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Atendimento;

public class AtendimentoDAO {

	public void create(Atendimento a) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_atendimento VALUES (?,?,?,?,?) ";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlInsere);
		} catch (SQLException e6) {
			// TODO Auto-generated catch block
			e6.printStackTrace();
		}

		try {
			stmt.setString(1, a.getComentarioEnfermeiro());
		} catch (SQLException e5) {
			// TODO Auto-generated catch block
			e5.printStackTrace();
		}
		try {
			stmt.setString(2, a.getComentarioMedico());
		} catch (SQLException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			stmt.setFloat(3, a.getPeso());
		} catch (SQLException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		try {
			stmt.setFloat(4, a.getAltura());
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			stmt.setDate(5, (Date) a.getData());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	 * public void lista(Atendimento a) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlInsere =
	 * "select tb_pessoa.nome, tb_enfermidadepessoal.comentario, tb_enfermidadepessoal.statusDeEnfermidade from tb_enfermidadepessoal, tb_paciente, tb_pessoa order by tb_pessoa.nome"
	 * ; PreparedStatement stmt = conexao.prepareStatement(sqlInsere); ResultSet rs
	 * = stmt.executeQuery(); List<Atendimento> atendimentos = new
	 * ArrayList<Atendimento>(); while (rs.next()) { Atendimento a1 = new
	 * Atendimento(); a1.getComentarioEnfermeiro(); a1.getComentarioMedico();
	 * atendimentos.add(a1); }
	 * 
	 * }
	 */
}
