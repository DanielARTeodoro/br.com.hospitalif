/**
 * 
 */
package br.com.hospitalif.rascunho;

/**
 * @author Frank
 *
 */
public class FuncionarioPessoaController {

}
