/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Gerente;

/**
 * @author Daniel
 *
 */
public class GerenteDAO {

	public void create(Gerente g) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_enfermidadepessoal VALUES (?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setString(1, g.getCargo());
		

		stmt.execute();
	}	

}
