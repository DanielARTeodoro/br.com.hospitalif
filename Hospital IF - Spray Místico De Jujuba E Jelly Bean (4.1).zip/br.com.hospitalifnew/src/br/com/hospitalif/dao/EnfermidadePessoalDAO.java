/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.EnfermidadePessoal;

/**
 * @author Daniel
 *
 */
public class EnfermidadePessoalDAO {

	public void create(EnfermidadePessoal enfp) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_enfermidadepessoal VALUES (?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setString(1, enfp.getComentario());
		stmt.setString(2, enfp.getStatusDeEnfermidade());

		stmt.execute();
	}

}
