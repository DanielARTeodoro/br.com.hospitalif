/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Funcionario;

/**
 * @author Daniel
 *
 */
public class FuncionarioDAO {

	public void create(Funcionario f) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_funcionario VALUES (?,?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setString(1, f.getLogin());
		stmt.setString(2, f.getSenha());
		stmt.setString(3, f.getStatusDeUsuario());

		stmt.execute();
	}

}
