/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Enfermeiro;

/**
 * @author Daniel
 *
 */
public class EnfermeiroDAO {
	
	public void create(Enfermeiro en) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_enfermeiro VALUES (?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		stmt.setInt(1, en.getNumeroDeRegistroEnfermeiro());
		

		stmt.execute();
	}
	

}
