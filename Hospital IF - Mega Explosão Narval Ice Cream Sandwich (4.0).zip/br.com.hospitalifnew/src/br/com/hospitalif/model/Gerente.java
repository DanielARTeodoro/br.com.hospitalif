/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.model;

/**
 * @author Daniel
 *
 */
public class Gerente extends Funcionario {

	private String cargo;

	/**
	 * 
	 */
	public Gerente() {

		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * @param cargo the cargo to set
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

}
