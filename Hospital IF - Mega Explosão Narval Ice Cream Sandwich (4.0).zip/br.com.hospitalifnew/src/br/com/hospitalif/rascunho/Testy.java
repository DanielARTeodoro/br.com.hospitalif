/**
 * 
 */
package br.com.hospitalif.rascunho;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import br.com.hospitalif.conexao.Conexao;

/**
 * @author Daniel
 *
 */
public class Testy extends Conexao {

	/**
	 * 
	 */
	public Testy() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();

		/// Connection connection = new Conexao().getConnection();
		/// Pessoa pa = new Pessoa();
		/// pa.getNome();
		/// pa.setNome("Pedro");
		/// save(pa);
		/// System.out.println("Nome: " + pa);

		// Inserir no banco � assim!
		String sqlINSERE = "INSERT INTO tb_pessoa (nome)" + " VALUES(?)";

		PreparedStatement stnt = conexao.prepareStatement(sqlINSERE);

		stnt.setString(1, "Pedro");
		stnt.execute();
		//System.out.println(conn.getConnection());
		System.out.println("Conex�o aberta!");
		/// connection.close();
		conexao.close();

	}

}
