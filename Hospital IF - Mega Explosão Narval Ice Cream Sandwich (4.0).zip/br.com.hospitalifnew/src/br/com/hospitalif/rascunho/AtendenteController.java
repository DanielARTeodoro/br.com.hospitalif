package br.com.hospitalif.rascunho;

public class AtendenteController {

   

}
