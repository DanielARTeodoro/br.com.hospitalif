/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Atendimento;
import br.com.hospitalif.model.EnfermidadePessoal;

public class AtendimentoDAO {

	public void create(Atendimento a) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_atendimento VALUES (?,?,?,?,?) ";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlInsere);
		} catch (SQLException e6) {
			// TODO Auto-generated catch block
			e6.printStackTrace();
		}

		try {
			stmt.setString(1, a.getComentarioEnfermeiro());
		} catch (SQLException e5) {
			// TODO Auto-generated catch block
			e5.printStackTrace();
		}
		try {
			stmt.setString(2, a.getComentarioMedico());
		} catch (SQLException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		try {
			stmt.setFloat(3, a.getPeso());
		} catch (SQLException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		try {
			stmt.setFloat(4, a.getAltura());
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			stmt.setDate(5, java.sql.Date.valueOf(a.getData()));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void readDoenca(Atendimento a) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlLer = "select * from view_atendimento";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlLer);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<EnfermidadePessoal> atendimentos = new ArrayList<EnfermidadePessoal>();
		try {
			while (rs.next()) {
				EnfermidadePessoal a1 = new EnfermidadePessoal();
				a1.setComentario(rs.getString("comentario"));
				a1.setStatusDeEnfermidade(rs.getString("statusDeEnfermidade"));
				atendimentos.add(a1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

}