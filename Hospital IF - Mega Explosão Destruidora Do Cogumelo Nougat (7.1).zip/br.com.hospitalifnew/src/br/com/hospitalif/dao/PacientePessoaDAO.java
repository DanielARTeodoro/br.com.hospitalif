/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.dao;

public class PacientePessoaDAO {
/*	
	  public void read(PacientePessoa ppa) { 
	  Conexao conn = new Conexao(); 
	  Connection conexao = conn.getConnection();
	  System.out.println(conn.getStatus());
	  String sqlLer =
	  "select tb_pessoa.nome, tb_funcionariopessoa.numeroDeRegistroEnfermeiro, tb_funcionariopessoa.numeroDeRegistroMedico, tb_funcionariopessoa.especialidade, tb_atendimento*, tb_enfermidadepessoal.*, tb_enfermidade.*, tb_entrada.* from tb_pessoa, tb_funcionariopessoa, tb_atendimento, tb_enfermidadepessoal, tb_enfermidade, tb_entrada, tb_paciente group by tb_pessoa.nome ASC"; 
	  PreparedStatement stmt = null;
	try {
		stmt = conexao.prepareStatement(sqlLer);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  ResultSet rs = null;
	try {
		rs = stmt.executeQuery();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	  List<PacientePessoa> pacientePessoas = new ArrayList<PacientePessoa>(); 
	  try {
		while (rs.next()) { 
		  PacientePessoa ppa1 = new PacientePessoa(); 
		  ppa1.getComentarioEnfermeiro(); 
		  ppa1.getComentarioMedico();
		  pacientePessoas.add(ppa1); 
		  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
	  }*/

	  /*
		public void update(Atendimento a) throws SQLException {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlAtualizar = "UPDATE Atendimento a set(?,?,?,?,?) where id=(?) ";
			PreparedStatement stmt = conexao.prepareStatement(sqlAtualizar);

			stmt.setString(3, a.getComentarioEnfermeiro());
			stmt.setString(4, a.getComentarioMedico());
			stmt.setFloat(2, a.getPeso());
			stmt.setFloat(1, a.getAltura());
			stmt.setDate(5, (Date) a.getData());

			stmt.execute();

		}

		public void delete(int id) throws SQLException {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlApagar = "DELETE from Atendimento where id =(?)";
			PreparedStatement stmt = conexao.prepareStatement(sqlApagar);

			stmt.setInt(1, id);
			stmt.execute();

		}
	*/
/*
	private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean inserir(PacientePessoa pacientePessoa) {
        String sql = "INSERT INTO pacientePessoas(nome, Altura, Peso) VALUES(?,?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, pacientePessoa.getNome());
            stmt.setFloat(2, pacientePessoa.getAltura());
            stmt.setFloat(3, pacientePessoa.getPeso());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean alterar(PacientePessoa pacientePessoa) {
        String sql = "UPDATE pacientePessoas SET nome=?, altura=?, peso=? WHERE cdPacientePessoa=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, pacientePessoa.getNome());
            stmt.setFloat(2, pacientePessoa.getAltura());
            stmt.setFloat(3, pacientePessoa.getPeso());
            stmt.setInt(4, pacientePessoa.getCdPacientePessoa());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean remover(PacientePessoa pacientePessoa) {
        String sql = "DELETE FROM pacientePessoas WHERE cdPacientePessoa=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, pacientePessoa.getCdPacientePessoa());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<PacientePessoa> listar() {
        String sql = "SELECT * FROM pacientePessoas";
        List<PacientePessoa> retorno = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                PacientePessoa pacientePessoa = new PacientePessoa();
                pacientePessoa.setCdPacientePessoa(resultado.getInt("cdPacientePessoa"));
                pacientePessoa.setNome(resultado.getString("nome"));
                pacientePessoa.setAltura(resultado.getString("altura"));
                pacientePessoa.setPeso(resultado.getString("peso"));
                retorno.add(pacientePessoa);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }

    public PacientePessoa buscar(PacientePessoa pacientePessoa) {
        String sql = "SELECT * FROM pacientePessoas WHERE cdPacientePessoa=?";
        PacientePessoa retorno = new PacientePessoa();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, pacientePessoa.getCdPacientePessoa());
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
                pacientePessoa.setNome(resultado.getString("nome"));
                pacientePessoa.setAltura(resultado.getString("altura"));
                pacientePessoa.setPeso(resultado.getString("peso"));
                retorno = pacientePessoa;
            }
        } catch (SQLException ex) {
            Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
	*/
}