/**
 * 
 */
package br.com.hospitalif.rascunho;

public class FuncionarioPessoaController_Antigo {

}
