/**
 * Sample Skeleton for 'Funcionario.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.FuncionarioDAO;
import br.com.hospitalif.model.Funcionario;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FuncionarioController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnfuncionario"
	private Button btnfuncionario; // Value injected by FXMLLoader

	@FXML // fx:id="txtfuncionario0"
	private TextField txtfuncionario0; // Value injected by FXMLLoader

	@FXML // fx:id="txtfuncionario1"
	private TextField txtfuncionario1; // Value injected by FXMLLoader

	@FXML // fx:id="txtfuncionario2"
	private TextField txtfuncionario2; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws SQLException {

		if (txtfuncionario0.getText().equals("")) {
			Stage stage = (Stage) btnfuncionario.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.FUNCIONARIO));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(scene);
			stage.show();
		} else {
			Funcionario f = new Funcionario();
			FuncionarioDAO fD = new FuncionarioDAO();

			String login = (txtfuncionario0.getText());
			String senha = (txtfuncionario1.getText());
			String statusDeUsuario = (txtfuncionario2.getText());

			f.setLogin(login);
			f.setSenha(senha);
			f.setStatusDeUsuario(statusDeUsuario);

			fD.create(f);

			Stage stage = (Stage) btnfuncionario.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.GERENTE));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(scene);
			stage.show();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnfuncionario != null : "fx:id=\"btnfuncionario\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtfuncionario0 != null : "fx:id=\"txtfuncionario0\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtfuncionario1 != null : "fx:id=\"txtfuncionario1\" was not injected: check your FXML file 'Funcionario.fxml'.";
		assert txtfuncionario2 != null : "fx:id=\"txtfuncionario2\" was not injected: check your FXML file 'Funcionario.fxml'.";

	}
}
