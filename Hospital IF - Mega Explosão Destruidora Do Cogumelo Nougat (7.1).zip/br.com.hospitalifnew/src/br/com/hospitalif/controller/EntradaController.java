/**
 * Sample Skeleton for 'Entrada.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.EntradaDAO;
import br.com.hospitalif.model.Entrada;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EntradaController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnEntrada"
	private Button btnEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="idSPaciente"
	private TableView<?> idSPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="idNome"
	private TableColumn<?, ?> idNome; // Value injected by FXMLLoader

	@FXML // fx:id="idCEnfermeiro"
	private TableColumn<?, ?> idCEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="idCMedico"
	private TableColumn<?, ?> idCMedico; // Value injected by FXMLLoader

	@FXML // fx:id="idPeso"
	private TableColumn<?, ?> idPeso; // Value injected by FXMLLoader

	@FXML // fx:id="idAltura"
	private TableColumn<?, ?> idAltura; // Value injected by FXMLLoader

	@FXML // fx:id="idData"
	private TableColumn<?, ?> idData; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada"
	private TextField txtentrada; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada1"
	private DatePicker txtentrada1; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada2"
	private DatePicker txtentrada2; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws SQLException {

		if (txtentrada.getText().equals("")) {
			Stage stage = (Stage) btnEntrada.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.ENTRADA));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(scene);
			stage.show();
		} else {

			Entrada en = new Entrada();

			EntradaDAO enD = new EntradaDAO();

			LocalDate dataEntrada = txtentrada1.getValue();
			LocalDate dataSaida = txtentrada2.getValue();
			String statusEntrada = txtentrada.getPromptText();

			en.setDataEntrada(dataEntrada);
			en.setDataSaida(dataSaida);
			en.setStatusEntrada(statusEntrada);

			enD.create(en);

			Stage stage = (Stage) btnEntrada.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.PACIENTE));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(scene);
			stage.show();
		}

	}
/*	
	@FXML
    void relatorio(ActionEvent event) {
		String relatorio = "Entrada.jrxml";
		try {
			new PrintReport().showReport(relatorio);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	public void lista(URL arg0, ResourceBundle arg1) {
		idNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		idCEnfermeiro.setCellValueFactory(new PropertyValueFactory<>("comentarioEnfermeiro"));
		idCMedico.setCellValueFactory(new PropertyValueFactory<>("comentarioMedico"));
		idPeso.setCellValueFactory(new PropertyValueFactory<>("peso"));
		idAltura.setCellValueFactory(new PropertyValueFactory<>("altura"));
		idData.setCellValueFactory(new PropertyValueFactory<>("data"));
		
		

		EntradaDAO enDAO = new EntradaDAO();
		List<EnfermidadePessoal> entrada = enDAO.readSituacaoDePaciente(en);

		ObservableList<?> obsA = FXCollections.observableArrayList(entrada);

		idSPaciente.setItems(null);
		

	}
*/
	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnEntrada != null : "fx:id=\"btnEntrada\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idSPaciente != null : "fx:id=\"idSPaciente\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idNome != null : "fx:id=\"idNome\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idCEnfermeiro != null : "fx:id=\"idCEnfermeiro\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idCMedico != null : "fx:id=\"idCMedico\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idPeso != null : "fx:id=\"idPeso\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idAltura != null : "fx:id=\"idAltura\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert idData != null : "fx:id=\"idData\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtentrada != null : "fx:id=\"txtentrada\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtentrada1 != null : "fx:id=\"txtentrada1\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtentrada2 != null : "fx:id=\"txtentrada2\" was not injected: check your FXML file 'Entrada.fxml'.";

	}
}
