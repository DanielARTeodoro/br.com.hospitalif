/**
 * Sample Skeleton for 'Paciente.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class PacienteController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnCadastrar9; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente"
	private TableView<?> tabPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="idNome0"
	private TableColumn<?, ?> idNome0; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente0"
	private TableColumn<?, ?> tabPaciente0; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente1"
	private TableColumn<?, ?> tabPaciente1; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente2"
	private TableView<?> tabPaciente2; // Value injected by FXMLLoader

	@FXML // fx:id="idNome1"
	private TableColumn<?, ?> idNome1; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente3"
	private TableColumn<?, ?> tabPaciente3; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente4"
	private TableColumn<?, ?> tabPaciente4; // Value injected by FXMLLoader

	@FXML // fx:id="tabPaciente5"
	private TableColumn<?, ?> tabPaciente5; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {
		
		Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.HOME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
		stage.setTitle("HOME");
		stage.setScene(scene);
		stage.show();

	}
/*	
	public void listaA(URL arg0, ResourceBundle arg1) {
		idNome0.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tabPaciente0.setCellValueFactory(new PropertyValueFactory<>("comentario"));
		tabPaciente1.setCellValueFactory(new PropertyValueFactory<>("statusDeEnfermidade"));
		
		

		PacienteDAO paADAO = new PacienteDAO();
		List<EnfermidadePessoal> doencas = (List<EnfermidadePessoal>) paADAO.readDoenca(pa);

		
		ObservableList<?> obsA = FXCollections.observableArrayList(doencas);

		tabPaciente.setItems(obsA);
		

		
	}
	
	public void listaB(URL arg0, ResourceBundle arg1) {
		idNome0.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tabPaciente0.setCellValueFactory(new PropertyValueFactory<>("comentario"));
		tabPaciente1.setCellValueFactory(new PropertyValueFactory<>("statusDeEnfermidade"));
		
		

		PacienteDAO paBDAO = new PacienteDAO();
		List<EnfermidadePessoal> historicos = (List<EnfermidadePessoal>) paADAO.readHistorico(pa);

		ObservableList<?> obsA = FXCollections.observableArrayList(historicos);

		tabPaciente.setItems(null);
		

	}

	@FXML
    void relatorio(ActionEvent event) {
		String relatorio = "Paciente.jrxml";
		try {
			new PrintReport().showReport(relatorio);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
*/
	
	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnCadastrar9 != null : "fx:id=\"btnCadastrar9\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente != null : "fx:id=\"tabPaciente\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert idNome0 != null : "fx:id=\"idNome0\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente0 != null : "fx:id=\"tabPaciente0\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente1 != null : "fx:id=\"tabPaciente1\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente2 != null : "fx:id=\"tabPaciente2\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert idNome1 != null : "fx:id=\"idNome1\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente3 != null : "fx:id=\"tabPaciente3\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente4 != null : "fx:id=\"tabPaciente4\" was not injected: check your FXML file 'Paciente.fxml'.";
		assert tabPaciente5 != null : "fx:id=\"tabPaciente5\" was not injected: check your FXML file 'Paciente.fxml'.";

	}
}
