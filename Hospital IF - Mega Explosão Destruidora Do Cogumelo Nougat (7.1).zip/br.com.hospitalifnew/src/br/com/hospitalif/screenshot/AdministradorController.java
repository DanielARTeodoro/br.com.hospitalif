
/**
 * Sample Skeleton for 'Administrador.fxml' Controller Class
 */

package br.com.hospitalif.screenshot;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdministradorController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnFuncionario"
	private Button btnFuncionario; // Value injected by FXMLLoader

	@FXML
	void ir(ActionEvent event) throws IOException {
		Stage stage = (Stage) btnFuncionario.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("../view/Funcionario.fxml"));
		Scene scene = new Scene(root);
		/// scene.getStylesheets().add(getClass().getResource("/css/estilo.css").toExternalForm());
		stage.setTitle("Funcionario");
		stage.setScene(scene);
		stage.show();
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnFuncionario != null : "fx:id=\"btnFuncionario\" was not injected: check your FXML file 'Administrador.fxml'.";

	}
}

