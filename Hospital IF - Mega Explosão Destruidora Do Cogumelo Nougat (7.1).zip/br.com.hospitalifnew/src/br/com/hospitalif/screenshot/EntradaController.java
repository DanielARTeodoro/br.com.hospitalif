/**
 * Sample Skeleton for 'Entrada.fxml' Controller Class
 */

package br.com.hospitalif.screenshot;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class EntradaController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnEntrada"
	private Button btnEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada"
	private TextField txtStatusEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada1"
	private DatePicker txtDataEntrada; // Value injected by FXMLLoader

	@FXML // fx:id="txtentrada2"
	private DatePicker txtDataSaida; // Value injected by FXMLLoader
	
	private TableColumn<?, ?> txtNome; // Value injected by FXMLLoader
	
	private TableColumn<?, ?> txtComentarioEnfermeiro; // Value injected by FXMLLoader
	
	private TableColumn<?, ?> txtComentarioMedico; // Value injected by FXMLLoader
	
	private TableColumn<?, ?> txtPeso; // Value injected by FXMLLoader
	
	private TableColumn<?, ?> txtAltura; // Value injected by FXMLLoader

	private TableColumn<?, ?> txtData; // Value injected by FXMLLoader



	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnEntrada != null : "fx:id=\"btnEntrada\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtStatusEntrada != null : "fx:id=\"txtStatusEntrada\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtDataEntrada != null : "fx:id=\"txtDataEntrada\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtDataSaida != null : "fx:id=\"txtDataSaida\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtNome != null : "fx:id=\"txtNome\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtComentarioEnfermeiro != null : "fx:id=\"txtComentarioEnfermeiro\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtComentarioMedico != null : "fx:id=\"txtComentarioMedico\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtPeso != null : "fx:id=\"txtPeso\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtAltura != null : "fx:id=\"txtAltura\" was not injected: check your FXML file 'Entrada.fxml'.";
		assert txtData != null : "fx:id=\"txtData\" was not injected: check your FXML file 'Entrada.fxml'.";

	}
}
