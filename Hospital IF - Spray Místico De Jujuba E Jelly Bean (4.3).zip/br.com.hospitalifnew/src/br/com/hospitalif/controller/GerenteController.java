/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**

 * Sample Skeleton for 'gerente.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.GerenteDAO;
import br.com.hospitalif.model.Gerente;
import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author Daniel
 *
 */
public class GerenteController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnCadastrar9"
	private Button btnCadastrar9; // Value injected by FXMLLoader

	@FXML // fx:id="txtGerente"
	private TextField txtGerente; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) throws SQLException {

		if (txtGerente.getText().equals("")) {
			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.GERENTE));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: ERRO!");
			stage.setScene(scene);
			stage.show();
		} else {
			Gerente g = new Gerente();
			GerenteDAO gD = new GerenteDAO();

			String cargo = (txtGerente.getText());

			g.setCargo(cargo);

			gD.create(g);

			Stage stage = (Stage) btnCadastrar9.getScene().getWindow();
			Parent root = null;
			try {
				root = FXMLLoader.load(getClass().getResource(Rotas.GERENTE));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource(Rotas.APP).toExternalForm());
			stage.setTitle("Alerta: Sucesso!");
			stage.setScene(scene);
			stage.show();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert txtGerente != null : "fx:id=\"txtGerente\" was not injected: check your FXML file 'Gerente.fxml'.";

	}
}
