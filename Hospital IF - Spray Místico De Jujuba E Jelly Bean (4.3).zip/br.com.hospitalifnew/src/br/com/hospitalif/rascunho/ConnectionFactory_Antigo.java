/**
 * 
 */
//situa em qual package ou "pacote" est� a classe 

package br.com.hospitalif.rascunho;

//faz as importa��es de classes necess�rias para o funcionamento do programa 
import java.sql.Connection;
//conex�o SQL para Java 
import java.sql.DriverManager;
//driver de conex�o SQL para Java 
import java.sql.SQLException;
//classe para tratamento de exce��es 

/**
 * @author Daniel
 *
 */
public class ConnectionFactory_Antigo {

	public Connection getConnection() {
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost/tads4_bd", "root", "");
		} catch (SQLException excecao) {
			throw new RuntimeException(excecao);
		}
	}

}
