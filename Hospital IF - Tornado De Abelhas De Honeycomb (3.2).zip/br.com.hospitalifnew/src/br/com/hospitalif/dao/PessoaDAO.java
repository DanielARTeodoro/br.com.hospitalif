/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.Pessoa;

/**
 * @author Daniel
 *
 */
public class PessoaDAO {
	
	
	
	public static void criar(Pessoa p) throws SQLException {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_pessoa VALUES (?,?,?,?,?,?) ";
		PreparedStatement stmt = conexao.prepareStatement(sqlInsere);

		
		stmt.setString(2, p.getNome());
		stmt.setString(3, p.getCpf());
		stmt.setInt(4, p.getIdade());
		stmt.setString(5, p.getTipoSanguineo());
		
		
		stmt.setString(7, p.getStatusDePessoa());

		stmt.execute();
	}

}
