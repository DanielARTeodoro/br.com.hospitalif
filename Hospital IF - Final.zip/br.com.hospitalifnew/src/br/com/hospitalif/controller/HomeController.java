/**
 * Sample Skeleton for 'Home.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.hospitalif.util.Rotas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class HomeController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnAdm"
	private Button btnAdm; // Value injected by FXMLLoader

	@FXML // fx:id="btnAte"
	private Button btnAte; // Value injected by FXMLLoader

	@FXML // fx:id="btnEnfer"
	private Button btnEnfer; // Value injected by FXMLLoader

	@FXML // fx:id="btnGer"
	private Button btnGer; // Value injected by FXMLLoader

	@FXML // fx:id="btnMedico"
	private Button btnMedico; // Value injected by FXMLLoader

	@FXML // fx:id="btnFuncionarios"
	private Button btnFuncionarios; // Value injected by FXMLLoader

	@FXML // fx:id="btnPacientes"
	private Button btnPacientes; // Value injected by FXMLLoader

	@FXML // fx:id="idLogoff"
	private Button idLogoff; // Value injected by FXMLLoader

	@FXML
	void adm(ActionEvent event) {

		Stage stage = (Stage) btnAdm.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.ADMINISTRADOR));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.ADMINISTRADORCSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void ate(ActionEvent event) {

		Stage stage = (Stage) btnAte.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.ATENDENTE));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.ATENDENTECSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void enfer(ActionEvent event) {

		Stage stage = (Stage) btnEnfer.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.ENFERMEIRO));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.ENFERMEIROCSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void funcionarios(ActionEvent event) {

		Stage stage = (Stage) btnFuncionarios.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.FUNCIONARIOPESSOA));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.FUNCIONARIOPESSOACSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void ger(ActionEvent event) {

		Stage stage = (Stage) btnGer.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.GERENTE));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.ENFERMEIROCSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void logoff(ActionEvent event) {

		Stage stage = (Stage) idLogoff.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.LOGIN));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.LOGINCSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void medico(ActionEvent event) {

		Stage stage = (Stage) btnMedico.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.MEDICO));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.MEDICOCSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML
	void pacientes(ActionEvent event) {

		Stage stage = (Stage) btnPacientes.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.PACIENTEPESSOA));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.PACIENTEPESSOACSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnAdm != null : "fx:id=\"btnAdm\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnAte != null : "fx:id=\"btnAte\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnEnfer != null : "fx:id=\"btnEnfer\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnGer != null : "fx:id=\"btnGer\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnMedico != null : "fx:id=\"btnMedico\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnFuncionarios != null : "fx:id=\"btnFuncionarios\" was not injected: check your FXML file 'Home.fxml'.";
		assert btnPacientes != null : "fx:id=\"btnPacientes\" was not injected: check your FXML file 'Home.fxml'.";
		assert idLogoff != null : "fx:id=\"idLogoff\" was not injected: check your FXML file 'Home.fxml'.";

	}
}
