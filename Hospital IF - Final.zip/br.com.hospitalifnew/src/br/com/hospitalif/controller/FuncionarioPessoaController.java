/**
 * Sample Skeleton for 'FuncionarioPessoa.fxml' Controller Class
 */

package br.com.hospitalif.controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import br.com.hospitalif.dao.FuncionarioPessoaDAO;
import br.com.hospitalif.model.FuncionarioPessoa;
import br.com.hospitalif.util.Rotas;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FuncionarioPessoaController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="AreaEdicao"
	private AnchorPane AreaEdicao; // Value injected by FXMLLoader

	@FXML // fx:id="txtNome"
	private TextField txtNome; // Value injected by FXMLLoader

	@FXML // fx:id="txtCpf"
	private TextField txtCpf; // Value injected by FXMLLoader

	@FXML // fx:id="txtIdade"
	private TextField txtIdade; // Value injected by FXMLLoader

	@FXML // fx:id="txtTipoSanguineo"
	private TextField txtTipoSanguineo; // Value injected by FXMLLoader

	@FXML // fx:id="txtSexo"
	private TextField txtSexo; // Value injected by FXMLLoader

	@FXML // fx:id="txtEstadoPessoa"
	private TextField txtEstadoPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="txtLogin"
	private TextField txtLogin; // Value injected by FXMLLoader

	@FXML // fx:id="txtSenha"
	private TextField txtSenha; // Value injected by FXMLLoader

	@FXML // fx:id="txtStatus"
	private TextField txtStatus; // Value injected by FXMLLoader

	@FXML // fx:id="txtNumRegEnfermeiro"
	private TextField txtNumRegEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="txtCargo"
	private TextField txtCargo; // Value injected by FXMLLoader

	@FXML // fx:id="txtNumRegMedico"
	private TextField txtNumRegMedico; // Value injected by FXMLLoader

	@FXML // fx:id="txtExpecialidade"
	private TextField txtExpecialidade; // Value injected by FXMLLoader

	@FXML // fx:id="btnDeletarr"
	private Button btnDeletar; // Value injected by FXMLLoader

	@FXML // fx:id="idCFuncionarioPessoa"
	private TableView<FuncionarioPessoa> idCFuncionarioPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="idCNome"
	private TableColumn<FuncionarioPessoa, String> idCNome; // Value injected by FXMLLoader

	@FXML // fx:id="idCCpf"
	private TableColumn<FuncionarioPessoa, String> idCCpf; // Value injected by FXMLLoader

	@FXML // fx:id="idCIdade"
	private TableColumn<FuncionarioPessoa, Integer> idCIdade; // Value injected by FXMLLoader

	@FXML // fx:id="idCTipoSangue"
	private TableColumn<FuncionarioPessoa, String> idCTipoSangue; // Value injected by FXMLLoader

	@FXML // fx:id="idCSexo"
	private TableColumn<FuncionarioPessoa, String> idCSexo; // Value injected by FXMLLoader

	@FXML // fx:id="idCEstadoPessoa"
	private TableColumn<FuncionarioPessoa, String> idCEstadoPessoa; // Value injected by FXMLLoader

	@FXML // fx:id="idCLogin"
	private TableColumn<FuncionarioPessoa, String> idCLogin; // Value injected by FXMLLoader

	@FXML // fx:id="idCSenha"
	private TableColumn<FuncionarioPessoa, String> idCSenha; // Value injected by FXMLLoader

	@FXML // fx:id="idCStatusUsuario"
	private TableColumn<FuncionarioPessoa, String> idCStatusUsuario; // Value injected by FXMLLoader

	@FXML // fx:id="idCNumRegEnfermeiro"
	private TableColumn<FuncionarioPessoa, String> idCNumRegEnfermeiro; // Value injected by FXMLLoader

	@FXML // fx:id="idCCargo"
	private TableColumn<FuncionarioPessoa, String> idCCargo; // Value injected by FXMLLoader

	@FXML // fx:id="idCNumRegMedico"
	private TableColumn<FuncionarioPessoa, String> idCNumRegMedico; // Value injected by FXMLLoader

	@FXML // fx:id="idCExpecialidade"
	private TableColumn<FuncionarioPessoa, String> idCExpecialidade; // Value injected by FXMLLoader

	@FXML // fx:id="btnEditar"
	private Button btnEditar; // Value injected by FXMLLoader

	@FXML // fx:id="btnSalvar"
	private Button btnSalvar; // Value injected by FXMLLoader

	@FXML // fx:id="btnVoltar"
	private Button btnVoltar; // Value injected by FXMLLoader

	@FXML
	void Salvar(ActionEvent event) {
		try {
			AreaEdicao.setVisible(false);
			String nome = (txtNome.getText());
			String cpf = (txtCpf.getText());
			int idade = Integer.parseInt(txtIdade.getText());
			String tipoSanguineo = (txtTipoSanguineo.getText());
			String sexo = (txtSexo.getText());
			String statusDePessoa = (txtEstadoPessoa.getText());

			String login = (txtLogin.getText());
			String senha = (txtSenha.getText());
			String statusDeUsuario = (txtStatus.getText());

			int numeroDeRegistroEnfermeiro = Integer.parseInt(txtNumRegEnfermeiro.getText());

			String cargo = (txtCargo.getText());

			int numeroDeRegistroMedico = Integer.parseInt(txtNumRegMedico.getText());
			String especialidade = txtExpecialidade.getText();

			FuncionarioPessoa a = new FuncionarioPessoa();
			FuncionarioPessoaDAO aDAO = new FuncionarioPessoaDAO();
			FuncionarioPessoa getId = (FuncionarioPessoa) idCFuncionarioPessoa.getSelectionModel().getSelectedItem();
			a.setIdFuncionario(getId.getIdFuncionario());
			a.setNome(nome);
			a.setCpf(cpf);
			a.setIdade(idade);
			a.setTipoSanguineo(tipoSanguineo);
			a.setSexo(sexo);
			a.setStatusDePessoa(statusDePessoa);
			a.setLogin(login);
			a.setSenha(senha);
			a.setStatusDeUsuario(statusDeUsuario);
			a.setNumeroDeRegistroEnfermeiro(numeroDeRegistroEnfermeiro);
			a.setCargo(cargo);
			a.setNumeroDeRegistroMedico(numeroDeRegistroMedico);
			a.setEspecialidade(especialidade);
			aDAO.update(a);

		} catch (NumberFormatException e1) {
			e1.printStackTrace();
		}
	}

	@FXML
	void editar(ActionEvent event) {
		try {
			AreaEdicao.setVisible(true);
			FuncionarioPessoa a = (FuncionarioPessoa) idCFuncionarioPessoa.getSelectionModel().getSelectedItem();

			txtNome.setText(a.getNome());
			txtCpf.setText(a.getCpf());
			txtIdade.setText("" + a.getIdade());
			txtTipoSanguineo.setText(a.getTipoSanguineo());
			txtSexo.setText(a.getSexo());
			txtEstadoPessoa.setText(a.getStatusDePessoa());
			txtLogin.setText(a.getLogin());
			txtSenha.setText(a.getSenha());
			txtStatus.setText(a.getStatusDeUsuario());
			txtNumRegEnfermeiro.setText("" + a.getNumeroDeRegistroEnfermeiro());
			txtCargo.setText(a.getCargo());
			txtNumRegMedico.setText("" + a.getNumeroDeRegistroMedico());
			txtExpecialidade.setText(a.getEspecialidade());

		} catch (NullPointerException e) {
			AreaEdicao.setVisible(false);

		}
	}

	@FXML
	void excluir(ActionEvent event) throws SQLException {
		FuncionarioPessoa a = (FuncionarioPessoa) idCFuncionarioPessoa.getSelectionModel().getSelectedItem();
		System.out.println(a.getIdPessoa());
		FuncionarioPessoaDAO adao = new FuncionarioPessoaDAO();
		adao.delete(a.getIdPessoa());
		adao.delete(a.getIdFuncionario());
	}

	@FXML
	void voltar(ActionEvent event) throws IOException {

		Stage stage = (Stage) btnVoltar.getScene().getWindow();
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(Rotas.HOME));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource(Rotas.HOMECSS).toExternalForm());
		stage.setTitle("Hospital IF");
		stage.setScene(scene);
		stage.show();

	}

	public void initialize(URL arg0, ResourceBundle arg1) {
		idCNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		idCCpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
		idCIdade.setCellValueFactory(new PropertyValueFactory<>("idade"));
		idCTipoSangue.setCellValueFactory(new PropertyValueFactory<>("tipoSangue"));
		idCSexo.setCellValueFactory(new PropertyValueFactory<>("sexo"));
		idCEstadoPessoa.setCellValueFactory(new PropertyValueFactory<>("statusDePessoa"));
		idCLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
		idCSenha.setCellValueFactory(new PropertyValueFactory<>("senha"));
		idCStatusUsuario.setCellValueFactory(new PropertyValueFactory<>("statusDeUsuario"));
		idCNumRegEnfermeiro.setCellValueFactory(new PropertyValueFactory<>("numRegEnfermeiro"));
		idCCargo.setCellValueFactory(new PropertyValueFactory<>("cargo"));
		idCNumRegMedico.setCellValueFactory(new PropertyValueFactory<>("numRegMedico"));
		idCExpecialidade.setCellValueFactory(new PropertyValueFactory<>("expecialidade"));

		FuncionarioPessoaDAO adao = new FuncionarioPessoaDAO();
		List<FuncionarioPessoa> os = adao.read();
		ObservableList<FuncionarioPessoa> itens = FXCollections.observableArrayList(os);
		idCFuncionarioPessoa.setItems(itens);
		AreaEdicao.setVisible(false);
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert AreaEdicao != null : "fx:id=\"AreaEdicao\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtNome != null : "fx:id=\"txtNome\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtCpf != null : "fx:id=\"txtCpf\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtIdade != null : "fx:id=\"txtIdade\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtTipoSanguineo != null : "fx:id=\"txtTipoSanguineo\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtSexo != null : "fx:id=\"txtSexo\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtEstadoPessoa != null : "fx:id=\"txtEstadoPessoa\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtLogin != null : "fx:id=\"txtLogin\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtSenha != null : "fx:id=\"txtSenha\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtStatus != null : "fx:id=\"txtStatus\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtNumRegEnfermeiro != null : "fx:id=\"txtNumRegEnfermeiro\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtCargo != null : "fx:id=\"txtCargo\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtNumRegMedico != null : "fx:id=\"txtNumRegMedico\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert txtExpecialidade != null : "fx:id=\"txtExpecialidade\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert btnDeletar != null : "fx:id=\"btnCancelar\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCFuncionarioPessoa != null : "fx:id=\"idCFuncionarioPessoa\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCNome != null : "fx:id=\"idCNome\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCCpf != null : "fx:id=\"idCCpf\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCIdade != null : "fx:id=\"idCIdade\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCTipoSangue != null : "fx:id=\"idCTipoSangue\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCSexo != null : "fx:id=\"idCSexo\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCEstadoPessoa != null : "fx:id=\"idCEstadoPessoa\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCLogin != null : "fx:id=\"idCLogin\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCSenha != null : "fx:id=\"idCSenha\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCStatusUsuario != null : "fx:id=\"idCStatusUsuario\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCNumRegEnfermeiro != null : "fx:id=\"idCNumRegEnfermeiro\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCCargo != null : "fx:id=\"idCCargo\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCNumRegMedico != null : "fx:id=\"idCNumRegMedico\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert idCExpecialidade != null : "fx:id=\"idCExpecialidade\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert btnEditar != null : "fx:id=\"btnEditar\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert btnSalvar != null : "fx:id=\"btnSalvar\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";
		assert btnVoltar != null : "fx:id=\"btnVoltar\" was not injected: check your FXML file 'FuncionarioPessoa.fxml'.";

	}
}
