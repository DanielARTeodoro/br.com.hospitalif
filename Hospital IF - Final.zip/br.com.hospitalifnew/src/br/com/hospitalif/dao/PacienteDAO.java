/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */
package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.EnfermidadePessoal;
import br.com.hospitalif.model.Entrada;

public class PacienteDAO {

	public List<EnfermidadePessoal> doenca() {

		List<EnfermidadePessoal> pacienteDoencas = new ArrayList<EnfermidadePessoal>();
		try {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlLer = "select * from view_paciente0";
			PreparedStatement stmt = null;
			try {
				stmt = conexao.prepareStatement(sqlLer);
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			ResultSet rs = null;
			try {
				rs = stmt.executeQuery();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			while (rs.next()) {
				EnfermidadePessoal pa0 = new EnfermidadePessoal();
				pa0.setComentario(rs.getString("comentario"));
				pa0.setStatusDeEnfermidade(rs.getString("statusDeEnfermidade"));
				pacienteDoencas.add(pa0);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return pacienteDoencas;
	}

	public List<Entrada> historico() {

		List<Entrada> pacienteHistoricos = new ArrayList<Entrada>();
		try {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlLer = "select * from view_paciente1";
			PreparedStatement stmt = null;
			try {
				stmt = conexao.prepareStatement(sqlLer);
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			ResultSet rs = null;
			try {
				rs = stmt.executeQuery();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			while (rs.next()) {
				Entrada pa1 = new Entrada();
				pa1.setDataEntrada(rs.getDate("dataEntrada").toLocalDate());
				pa1.setDataSaida(rs.getDate("dataSaida").toLocalDate());
				pa1.setStatusEntrada(rs.getString("statusEntrada"));
				pacienteHistoricos.add(pa1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block

		}

		return pacienteHistoricos;
	}
}