/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 */

package br.com.hospitalif.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.hospitalif.conexao.Conexao;
import br.com.hospitalif.model.PacientePessoa;

public class PacientePessoaDAO {
	/*
	 * public void read(PacientePessoaController ppa) { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlLer =
	 * "select tb_pessoa.nome, tb_funcionariopessoa.numeroDeRegistroEnfermeiro, tb_funcionariopessoa.numeroDeRegistroMedico, tb_funcionariopessoa.especialidade, tb_atendimento*, tb_enfermidadepessoal.*, tb_enfermidade.*, tb_entrada.* from tb_pessoa, tb_funcionariopessoa, tb_atendimento, tb_enfermidadepessoal, tb_enfermidade, tb_entrada, tb_paciente group by tb_pessoa.nome ASC"
	 * ; PreparedStatement stmt = null; try { stmt =
	 * conexao.prepareStatement(sqlLer); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } ResultSet rs = null; try {
	 * rs = stmt.executeQuery(); } catch (SQLException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } List<PacientePessoaController>
	 * pacientePessoas = new ArrayList<PacientePessoaController>(); try { while
	 * (rs.next()) { PacientePessoaController ppa1 = new PacientePessoaController();
	 * ppa1.getComentarioEnfermeiro(); ppa1.getComentarioMedico();
	 * pacientePessoas.add(ppa1); } } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 */

	/*
	 * public void update(Atendimento a) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlAtualizar =
	 * "UPDATE Atendimento a set(?,?,?,?,?) where id=(?) "; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlAtualizar);
	 * 
	 * stmt.setString(3, a.getComentarioEnfermeiro()); stmt.setString(4,
	 * a.getComentarioMedico()); stmt.setFloat(2, a.getPeso()); stmt.setFloat(1,
	 * a.getAltura()); stmt.setDate(5, (Date) a.getData());
	 * 
	 * stmt.execute();
	 * 
	 * }
	 * 
	 * public void delete(int id) throws SQLException { Conexao conn = new
	 * Conexao(); Connection conexao = conn.getConnection();
	 * System.out.println(conn.getStatus()); String sqlApagar =
	 * "DELETE from Atendimento where id =(?)"; PreparedStatement stmt =
	 * conexao.prepareStatement(sqlApagar);
	 * 
	 * stmt.setInt(1, id); stmt.execute();
	 * 
	 * }
	 */
	/*
	 * private Connection connection;
	 * 
	 * public Connection getConnection() { return connection; }
	 * 
	 * public void setConnection(Connection connection) { this.connection =
	 * connection; }
	 * 
	 * public boolean inserir(PacientePessoaController pacientePessoa) { String sql
	 * = "INSERT INTO pacientePessoas(nome, Altura, Peso) VALUES(?,?,?)"; try {
	 * PreparedStatement stmt = connection.prepareStatement(sql); stmt.setString(1,
	 * pacientePessoa.getNome()); stmt.setFloat(2, pacientePessoa.getAltura());
	 * stmt.setFloat(3, pacientePessoa.getPeso()); stmt.execute(); return true; }
	 * catch (SQLException ex) {
	 * Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null,
	 * ex); return false; } }
	 * 
	 * public boolean alterar(PacientePessoaController pacientePessoa) { String sql
	 * =
	 * "UPDATE pacientePessoas SET nome=?, altura=?, peso=? WHERE cdPacientePessoa=?"
	 * ; try { PreparedStatement stmt = connection.prepareStatement(sql);
	 * stmt.setString(1, pacientePessoa.getNome()); stmt.setFloat(2,
	 * pacientePessoa.getAltura()); stmt.setFloat(3, pacientePessoa.getPeso());
	 * stmt.setInt(4, pacientePessoa.getCdPacientePessoa()); stmt.execute(); return
	 * true; } catch (SQLException ex) {
	 * Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null,
	 * ex); return false; } }
	 * 
	 * public boolean remover(PacientePessoaController pacientePessoa) { String sql
	 * = "DELETE FROM pacientePessoas WHERE cdPacientePessoa=?"; try {
	 * PreparedStatement stmt = connection.prepareStatement(sql); stmt.setInt(1,
	 * pacientePessoa.getCdPacientePessoa()); stmt.execute(); return true; } catch
	 * (SQLException ex) {
	 * Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null,
	 * ex); return false; } }
	 * 
	 * public List<PacientePessoaController> listar() { String sql =
	 * "SELECT * FROM pacientePessoas"; List<PacientePessoaController> retorno = new
	 * ArrayList<>(); try { PreparedStatement stmt =
	 * connection.prepareStatement(sql); ResultSet resultado = stmt.executeQuery();
	 * while (resultado.next()) { PacientePessoaController pacientePessoa = new
	 * PacientePessoaController();
	 * pacientePessoa.setCdPacientePessoa(resultado.getInt("cdPacientePessoa"));
	 * pacientePessoa.setNome(resultado.getString("nome"));
	 * pacientePessoa.setAltura(resultado.getString("altura"));
	 * pacientePessoa.setPeso(resultado.getString("peso"));
	 * retorno.add(pacientePessoa); } } catch (SQLException ex) {
	 * Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null,
	 * ex); } return retorno; }
	 * 
	 * public PacientePessoaController buscar(PacientePessoaController
	 * pacientePessoa) { String sql =
	 * "SELECT * FROM pacientePessoas WHERE cdPacientePessoa=?";
	 * PacientePessoaController retorno = new PacientePessoaController(); try {
	 * PreparedStatement stmt = connection.prepareStatement(sql); stmt.setInt(1,
	 * pacientePessoa.getCdPacientePessoa()); ResultSet resultado =
	 * stmt.executeQuery(); if (resultado.next()) {
	 * pacientePessoa.setNome(resultado.getString("nome"));
	 * pacientePessoa.setAltura(resultado.getString("altura"));
	 * pacientePessoa.setPeso(resultado.getString("peso")); retorno =
	 * pacientePessoa; } } catch (SQLException ex) {
	 * Logger.getLogger(PacientePessoaDAO.class.getName()).log(Level.SEVERE, null,
	 * ex); } return retorno; }
	 */

	public void create(PacientePessoa ppa) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlInsere = "INSERT INTO tb_pessoa VALUES (?,?,?,?,?,?) ";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlInsere);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(1, ppa.getNome());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(2, ppa.getCpf());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(3, ppa.getIdade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(4, ppa.getTipoSanguineo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(5, ppa.getSexo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(6, ppa.getStatusDePessoa());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlInsere1 = "INSERT INTO tb_atendimento VALUES (?,?,?,?,?) ";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlInsere1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt1.setString(1, ppa.getComentarioEnfermeiro());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(2, ppa.getComentarioMedico());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setFloat(3, ppa.getPeso());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setFloat(4, ppa.getAltura());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setDate(5, java.sql.Date.valueOf(ppa.getData()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlInsere2 = "INSERT INTO tb_enfermidadepessoal VALUES (?,?) ";
		PreparedStatement stmt2 = null;
		try {
			stmt2 = conexao.prepareStatement(sqlInsere2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt2.setString(1, ppa.getComentario());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt2.setString(2, ppa.getStatusDeEnfermidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlInsere3 = "INSERT INTO tb_enfermidade VALUES (?,?,?) ";
		PreparedStatement stmt3 = null;
		try {
			stmt3 = conexao.prepareStatement(sqlInsere3);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt3.setString(1, ppa.getNomeEnfermidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.setString(2, ppa.getTipo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.setString(3, ppa.getDescricao());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlInsere4 = "INSERT INTO tb_entrada VALUES (?,?,?) ";
		PreparedStatement stmt4 = null;
		try {
			stmt4 = conexao.prepareStatement(sqlInsere4);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt4.setDate(1, java.sql.Date.valueOf(ppa.getDataEntrada()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.setDate(2, java.sql.Date.valueOf(ppa.getDataSaida()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.setString(3, ppa.getStatusEntrada());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt2.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void delete(int id) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlDeleta = "DELETE from tb_pessoa where idAtendimento =(?)";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlDeleta);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlDeleta1 = "DELETE from tb_atendimento where idAtendimento =(?)";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlDeleta1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlDeleta2 = "DELETE from tb_enfermidadepessoal where idAtendimento =(?)";
		PreparedStatement stmt2 = null;
		try {
			stmt2 = conexao.prepareStatement(sqlDeleta2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlDeleta3 = "DELETE from tb_enfermidade where idAtendimento =(?)";
		PreparedStatement stmt3 = null;
		try {
			stmt3 = conexao.prepareStatement(sqlDeleta3);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlDeleta4 = "DELETE from tb_entrada where idAtendimento =(?)";
		PreparedStatement stmt4 = null;
		try {
			stmt4 = conexao.prepareStatement(sqlDeleta4);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(1, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt2.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<PacientePessoa> read() {
		List<PacientePessoa> pacientes = new ArrayList<PacientePessoa>();
		try {
			Conexao conn = new Conexao();
			Connection conexao = conn.getConnection();
			System.out.println(conn.getStatus());
			String sqlLer = "select * from view_pacientepessoa";
			PreparedStatement stmt = conexao.prepareStatement(sqlLer);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				PacientePessoa ppa1 = new PacientePessoa();

				ppa1.setNome(rs.getString("nome"));
				ppa1.setCpf(rs.getString("cpf"));
				ppa1.setIdade(rs.getInt("idade"));
				ppa1.setTipoSanguineo(rs.getString("tipoSanguineo"));
				ppa1.setSexo(rs.getString("sexo"));
				ppa1.setStatusDePessoa(rs.getString("statusDePessoa"));
				ppa1.setComentarioEnfermeiro(rs.getString("comentarioEnfermeiro"));
				ppa1.setComentarioMedico(rs.getString("comentarioMedico"));
				ppa1.setPeso(rs.getFloat("peso"));
				ppa1.setAltura(rs.getFloat("altura"));
				ppa1.setData(rs.getDate("data").toLocalDate());
				ppa1.setComentario(rs.getString("comentario"));
				ppa1.setStatusDeEnfermidade(rs.getString("statusDeEnfermidade"));
				ppa1.setNomeEnfermidade(rs.getString("nomeEnfermidade"));
				ppa1.setTipo(rs.getString("tipo"));
				ppa1.setDescricao(rs.getString("descricao"));
				ppa1.setDataEntrada(rs.getDate("dataEntrada").toLocalDate());
				ppa1.setDataSaida(rs.getDate("dataSaida").toLocalDate());
				ppa1.setStatusEntrada(rs.getString("statusEntrada"));

				pacientes.add(ppa1);
			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return pacientes;

	}

	public void update(PacientePessoa ppa0) {
		Conexao conn = new Conexao();
		Connection conexao = conn.getConnection();
		System.out.println(conn.getStatus());
		String sqlEditar = "update tb_pessoa set nome=(?),cpf =(?),idade=(?),tipoSanguineo=(?),sexo=(?),statusDePessoa=(?) where idPessoa=(?)";
		PreparedStatement stmt = null;
		try {
			stmt = conexao.prepareStatement(sqlEditar);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.setString(1, ppa0.getNome());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(2, ppa0.getCpf());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setInt(3, ppa0.getIdade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(4, ppa0.getTipoSanguineo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(5, ppa0.getSexo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.setString(6, ppa0.getStatusDePessoa());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlEditar1 = "update tb_atendimento set comentarioEnfermeiro=(?),comentarioMedico =(?),peso=(?),altura=(?),dataAtendimento=(?) where idAtendimento=(?)";
		PreparedStatement stmt1 = null;
		try {
			stmt1 = conexao.prepareStatement(sqlEditar1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt1.setString(1, ppa0.getComentarioEnfermeiro());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setString(2, ppa0.getComentarioMedico());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setFloat(3, ppa0.getPeso());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setFloat(4, ppa0.getAltura());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.setDate(5, java.sql.Date.valueOf(ppa0.getData()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlEditar2 = "update tb_enfermidadepessoal set comentario=(?),statusDeEnfermidade =(?) where idEnfermidadePessoal=(?)";
		PreparedStatement stmt2 = null;
		try {
			stmt2 = conexao.prepareStatement(sqlEditar2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt2.setString(1, ppa0.getComentario());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt2.setString(2, ppa0.getStatusDeEnfermidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlEditar3 = "update tb_enfermidade set nomeEnfermidade=(?),tipo =(?),descricao=(?) where ididEnfermidade=(?)";
		PreparedStatement stmt3 = null;
		try {
			stmt3 = conexao.prepareStatement(sqlEditar3);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt3.setString(1, ppa0.getNomeEnfermidade());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.setString(2, ppa0.getTipo());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.setString(3, ppa0.getDescricao());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sqlEditar4 = "update tb_entrada set dataEntrada=(?),dataSaida =(?),statusEntrada=(?) where idEntrada=(?)";
		PreparedStatement stmt4 = null;
		try {
			stmt4 = conexao.prepareStatement(sqlEditar4);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt4.setDate(1, java.sql.Date.valueOf(ppa0.getDataEntrada()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.setDate(2, java.sql.Date.valueOf(ppa0.getDataSaida()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.setString(3, ppa0.getStatusEntrada());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			stmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt1.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt2.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt3.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt4.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}