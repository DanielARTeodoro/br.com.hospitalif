/**
 * 
 */
package br.com.hospitalif.rascunho;

import java.sql.Connection;
import java.sql.SQLException;

import br.com.hospitalif.conexao.Conexao;

/**
 * @author Daniel
 *
 */
public class Testy {

	/**
	 * 
	 */
	public Testy() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Connection connection = new Conexao().getConnection();
		/// Pessoa pa = new Pessoa();
		/// pa.getNome();
		/// pa.setNome("Pedro");
		/// save(pa);
		/// System.out.println("Nome: " + pa);
		System.out.println("Conex�o aberta!");
		connection.close();

	}

}
